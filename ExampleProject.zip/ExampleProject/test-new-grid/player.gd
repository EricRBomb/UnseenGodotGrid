extends CharacterBody2D
#https://docs.godotengine.org/en/stable/tutorials/physics/using_character_body_2d.html

#How many pixels per second our character should move. Feel free to change this around!
const SPEED = 200.0 
#audio players
var step_sfx = AudioStreamPlayer.new()
var bonk = AudioStreamPlayer.new()
var impact_alert = AudioStreamPlayer.new()
#impact detector
var impact_detect = ShapeCast2D.new()

var collide

const DRIVING_SOUND = preload("res://sounds/driving_sound.mp3")
const BONK = preload("res://sounds/bonk.mp3")
const IMPACT_ALERT = preload("res://sounds/impact_alert.wav")

func _ready():
	motion_mode = CharacterBody2D.MOTION_MODE_FLOATING
	#making a smaller hit box for our player, making it red. GM is a addon from the extension, not part of godot.
	GM.create_collide_rect(32,32,self,true,Color.RED)
	#Using a GMAP added function here as well to map key board keys to also work as well as arrow keys as directions.
	#Arrow keys by default are part of ui_ in all godot projects
	GM.add_event("ui_left",KEY_A)
	GM.add_event("ui_right",KEY_D)
	GM.add_event("ui_up",KEY_W)
	GM.add_event("ui_down",KEY_S)
	#assinging the streams the imported audio files
	step_sfx.stream = DRIVING_SOUND
	bonk.stream = BONK
	impact_alert.stream = IMPACT_ALERT
	#Created objects won't impact the game until added as a child, they are in the void until then.
	add_child(step_sfx)
	add_child(bonk)
	add_child(impact_alert)
	#Change this to adjust how loud hitting a wall is.
	bonk.volume_db = -10
	#Configuring out shapecast, which will check for any impacts on our length so we can warn the player.
	#First we are saying to use a shape the same size as our player for the checking. Which is a 32x32 rectangle
	var collide_shape = RectangleShape2D.new()
	collide_shape.size = Vector2(32,32)
	#We are saying to detect 64 pixels out, then in our movement code we rotate the impact detector to be checking the direction the player is moving.
	impact_detect.target_position = Vector2(0,64)
	impact_detect.shape = collide_shape
	add_child(impact_detect)
	
func _process(delta):
	#checks each step where to move
	if Input.is_action_pressed("ui_left"):
		velocity = Vector2(-SPEED,0)
		impact_detect.rotation_degrees =90
	elif Input.is_action_pressed("ui_right"):
		velocity = Vector2(SPEED,0)
		impact_detect.rotation_degrees =-90
	elif Input.is_action_pressed("ui_up"):
		velocity = Vector2(0,-SPEED)
		impact_detect.rotation_degrees =180
	elif Input.is_action_pressed("ui_down"):
		velocity = Vector2(0,SPEED)
		impact_detect.rotation_degrees =0
	else:
		velocity = (Vector2(0,0))
	#This is a built in function of the characterbody2d that uses the velocity to move around
	#Because we set the motion mode to floating, it will change how certain things function.
	collide = move_and_collide(velocity * delta)
	motor_volume()
	impact_warning()

#function that will make it so as we move our little motor will get louder, and always be looping. 
func motor_volume():
	#keep looping
	if step_sfx.playing == false:
		step_sfx.play()
	if velocity == (Vector2(0,0)):
		#How loud our engine will be while "idle"
		step_sfx.volume_db = -40
	else:
		#change this until your volume is good indicator it is moving, I start with it rather soft.
		step_sfx.volume_db = -20
	#If we hit a wall and we're not already playing bonk, play bonk.
	if collide and bonk.playing == false:
		bonk.play()
#function to use the built in GMAP in game map. Pressing escape will pull up a map, allowing you to confirm everything is working or help navigate
func _unhandled_input(_event):
	if Input.is_action_just_pressed("ui_cancel"):
		get_parent().gmap_view_map(global_position,11,"ui_cancel")
#function that is checking if need to play alarm sound
func impact_warning():
	#simple check if our shape cast is hitting anything, to start playing if we detect a collision and not already playing
	if impact_detect.is_colliding():
		if impact_alert.playing == false:
			impact_alert.play()
	else:
		impact_alert.stop()
