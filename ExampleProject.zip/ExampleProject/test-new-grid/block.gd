extends StaticBody2D

func _ready():
	#Just make a black 64 x 64 box.
	GM.create_collide_rect(64,64,self,true,Color.BLACK)
