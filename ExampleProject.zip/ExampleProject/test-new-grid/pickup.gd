extends Area2D

var shiny = AudioStreamPlayer2D.new()
var pickup = AudioStreamPlayer.new()


const PICKUP = preload("uid://vk65ydgi3h3p")
const SHINY = preload("uid://btqyqoe5j2fcl")

var picked_up = 0

func _ready():
	#creating 
	GM.create_collide_rect(32,32,self,true,Color.YELLOW)
	pickup.stream = PICKUP
	shiny.stream = SHINY
	add_child(pickup)
	add_child(shiny)
	shiny.max_distance = 500
	shiny.panning_strength = 20
	shiny.play()
	
func _on_body_entered(body: Node2D) -> void:
	if picked_up == 0:
		picked_up = 1
		pickup.play()
		shiny.stop()
		
func _process(_delta):
	if picked_up == 0 and shiny.playing == false:
		shiny.play()
